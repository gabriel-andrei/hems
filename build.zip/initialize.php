<?php
$dev_data = array('id'=>'-1','firstname'=>'Developer','lastname'=>'','username'=>'admin','password'=>'5da283a2d990e8d8512cf967df5bc0d0','last_login'=>'','date_updated'=>'','date_added'=>'');
if(!defined('base_url')) define('base_url','http://localhost/hems/');
if(!defined('base_app')) define('base_app', str_replace('\\','/',__DIR__).'/' );
if(!defined('DB_SERVER')) define('DB_SERVER',"sql106.epizy.com");
if(!defined('DB_USERNAME')) define('DB_USERNAME',"epiz_32806673	");
if(!defined('DB_PASSWORD')) define('DB_PASSWORD',"xis6cMwwkv5NWus");
if(!defined('DB_NAME')) define('DB_NAME',"epiz_32806673_hems_db");
?>