-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.19-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             12.0.0.6468
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for hems_db
CREATE DATABASE IF NOT EXISTS `hems_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `hems_db`;

-- Dumping structure for table hems_db.clients_record
DROP TABLE IF EXISTS `clients_record`;
CREATE TABLE IF NOT EXISTS `clients_record` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `date_created` datetime NOT NULL,
  `trans_ref` int(11) DEFAULT NULL,
  `client_name` varchar(250) NOT NULL,
  `contact` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `engine_model` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.clients_record: ~6 rows (approximately)
INSERT INTO `clients_record` (`id`, `date_created`, `trans_ref`, `client_name`, `contact`, `address`, `engine_model`) VALUES
	(2, '2022-10-03 00:13:12', 5, 'Sample Name', '09837235621', 'Calapan City', '4D33'),
	(4, '2022-11-06 23:38:57', 12, 'Someone', '09123456789', 'address', '4D33'),
	(5, '2022-11-07 11:31:54', 13, 'John Doe', '09837635267', 'Calapan City, Ibaba', '4D33'),
	(6, '2022-11-07 20:11:35', 15, 'Bob Ross', '09837635267', 'Calapan City, Ibaba', '4D33'),
	(7, '2022-11-17 00:46:40', 19, 'Somepip', '091234', 'somewhere pips', '4d322'),
	(8, '2022-11-17 00:49:21', 21, 'Somebimby', '091234', 'somewhere pips', '4d322');

-- Dumping structure for table hems_db.inventory_list
DROP TABLE IF EXISTS `inventory_list`;
CREATE TABLE IF NOT EXISTS `inventory_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT '0',
  `unit` varchar(50) NOT NULL DEFAULT '',
  `stock_date` date NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `product_id_fk_il` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.inventory_list: ~5 rows (approximately)
INSERT INTO `inventory_list` (`id`, `product_id`, `quantity`, `unit`, `stock_date`, `date_created`, `date_updated`) VALUES
	(28, 51, 5, 'pcs', '2022-10-03', '2022-10-03 00:13:12', '2022-11-17 21:45:29'),
	(29, 50, 10, 'pcs', '2022-10-05', '2022-10-05 15:27:58', '2022-11-17 21:45:31'),
	(30, 51, 15, 'pcs', '2022-10-31', '2022-11-02 21:36:28', '2022-11-17 21:45:31'),
	(31, 33, 20, 'pcs', '2022-11-06', '2022-11-06 18:34:06', '2022-11-17 21:45:31'),
	(32, 32, 12, 'pcs', '2022-11-06', '2022-11-06 18:38:54', '2022-11-17 21:45:31'),
	(33, 35, 1, 'pcs', '2022-11-17', '2022-11-17 22:31:00', '2022-11-17 22:31:00');

-- Dumping structure for table hems_db.mechanic_list
DROP TABLE IF EXISTS `mechanic_list`;
CREATE TABLE IF NOT EXISTS `mechanic_list` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) NOT NULL,
  `middlename` text,
  `lastname` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_flag` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.mechanic_list: ~21 rows (approximately)
INSERT INTO `mechanic_list` (`id`, `firstname`, `middlename`, `lastname`, `status`, `delete_flag`, `date_added`, `date_updated`) VALUES
	(3, 'Alexis', '', 'Del Mundo', 1, 0, '2022-09-30 23:48:09', '2022-09-30 23:48:09'),
	(4, 'Alfie', '', 'Del Mundo', 1, 0, '2022-09-30 23:48:25', '2022-09-30 23:48:25'),
	(5, 'Joseph', '', 'Ribon', 1, 0, '2022-09-30 23:48:42', '2022-09-30 23:48:42'),
	(6, 'Arnel', '', 'Malaluan', 1, 0, '2022-09-30 23:48:58', '2022-09-30 23:48:58'),
	(7, 'Joey', '', ' Marasigan', 1, 0, '2022-09-30 23:49:16', '2022-09-30 23:49:16'),
	(8, 'Jeztrill', '', 'Tumamak', 1, 0, '2022-09-30 23:49:32', '2022-09-30 23:49:32'),
	(9, 'Aljon', '', 'Del Mundo', 1, 0, '2022-09-30 23:49:49', '2022-09-30 23:49:49'),
	(10, 'Ruperto ', '', 'Baliton', 1, 0, '2022-09-30 23:50:10', '2022-09-30 23:50:10'),
	(11, 'John Patrick', '', 'Hatulan', 1, 0, '2022-09-30 23:50:27', '2022-09-30 23:50:27'),
	(12, 'Edbert ', '', 'Hatulan', 1, 0, '2022-09-30 23:50:44', '2022-09-30 23:50:44'),
	(13, 'Jerry', '', 'Albo', 1, 0, '2022-09-30 23:50:55', '2022-09-30 23:50:55'),
	(14, 'Michael', '', 'Mores', 1, 0, '2022-09-30 23:51:05', '2022-09-30 23:51:05'),
	(15, 'Jerry', '', 'Roles', 1, 0, '2022-09-30 23:51:15', '2022-09-30 23:51:15'),
	(16, 'Royland', '', 'Malaluan', 1, 0, '2022-09-30 23:51:27', '2022-09-30 23:51:27'),
	(17, 'Allan', '', 'Garma', 1, 0, '2022-09-30 23:51:35', '2022-09-30 23:51:35'),
	(18, 'Jojimar', '', 'Robles', 1, 0, '2022-09-30 23:51:46', '2022-09-30 23:51:46'),
	(19, 'Christian', '', 'Ninal', 1, 0, '2022-09-30 23:51:59', '2022-09-30 23:51:59'),
	(20, 'Ronal', '', 'Lualhati', 1, 0, '2022-09-30 23:52:15', '2022-09-30 23:52:15'),
	(21, 'Jerome', '', 'Cleofe', 1, 0, '2022-09-30 23:52:25', '2022-09-30 23:52:25'),
	(22, 'Henry', '', 'Patulot', 1, 0, '2022-09-30 23:52:41', '2022-09-30 23:52:41'),
	(23, 'Ronald', '', 'Gozar', 1, 0, '2022-09-30 23:52:57', '2022-09-30 23:52:57');

-- Dumping structure for table hems_db.payment_list
DROP TABLE IF EXISTS `payment_list`;
CREATE TABLE IF NOT EXISTS `payment_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `transaction_id` int(11) NOT NULL DEFAULT '0',
  `payment_id` varchar(250) NOT NULL,
  `client_name` varchar(250) NOT NULL,
  `balance` float(15,2) NOT NULL,
  `total_amount` float(15,2) NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.payment_list: ~1 rows (approximately)
INSERT INTO `payment_list` (`id`, `date_created`, `transaction_id`, `payment_id`, `client_name`, `balance`, `total_amount`, `status`) VALUES
	(1, '2022-09-29 23:53:14', 21, '2147483647', 'Sample Name', 120.00, 120.00, 1);

-- Dumping structure for table hems_db.product_list
DROP TABLE IF EXISTS `product_list`;
CREATE TABLE IF NOT EXISTS `product_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `engine_model` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT '0.00',
  `unit` varchar(50) NOT NULL DEFAULT '0.00',
  `lowstock` int(11) NOT NULL DEFAULT '0',
  `image_path` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_flag` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.product_list: ~35 rows (approximately)
INSERT INTO `product_list` (`id`, `name`, `engine_model`, `description`, `price`, `unit`, `lowstock`, `image_path`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
	(26, 'Overhauling Gasaket', '4D56', '', 1900.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:18:03', '2022-11-17 21:46:08'),
	(27, 'Main Bearing', '4D56', '', 1500.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:18:35', '2022-11-17 21:46:08'),
	(28, 'Conn Bearing	', '4D56', '', 850.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:19:11', '2022-11-17 21:46:08'),
	(29, 'Trust Washer', '4D56', '', 450.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:19:29', '2022-11-17 21:46:08'),
	(30, 'Piston Assembly	', '4D56', '', 4500.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:19:51', '2022-11-17 21:46:08'),
	(31, 'PistonRing ', '4D56', '', 1800.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:20:16', '2022-11-17 21:46:08'),
	(32, 'Oil Filter	', '4D56', '', 450.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:23:06', '2022-11-17 21:46:08'),
	(33, 'Heater Plug', '4D56', '', 300.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:23:27', '2022-11-17 21:46:08'),
	(34, 'Fuel Filter', '4D56', '', 850.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:23:40', '2022-11-17 21:46:08'),
	(35, 'Clutch Disc ', '4D56', '', 1600.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:26:45', '2022-11-17 21:46:08'),
	(36, 'Con Rod Arm	', '4D32', '', 850.00, 'pcs', 1, '', 1, 0, '2022-10-02 23:27:03', '2022-11-17 22:40:27'),
	(37, 'Preasure Plate	', '4D56', '', 1700.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:27:25', '2022-11-17 21:46:08'),
	(38, 'Timing Belt 	', '4D56', '', 1500.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:27:42', '2022-11-17 21:46:08'),
	(39, 'Tensioner B', '4D56', '', 1600.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:27:58', '2022-11-17 21:46:08'),
	(40, 'Tensioner S', '4D56', '', 750.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:28:13', '2022-11-17 21:46:08'),
	(41, 'Rocker Arm Shaft', '4D56', '', 1600.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:28:31', '2022-11-17 21:46:08'),
	(42, 'MainBearing', '4D33', '', 1800.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:30:10', '2022-11-17 21:46:08'),
	(43, 'ConnBearing ', '4D33', '', 2100.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:30:41', '2022-11-17 21:46:08'),
	(44, 'TrustWasher ', '', '', 600.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:31:04', '2022-11-17 21:46:08'),
	(45, 'Liner2', '4D33', '', 6000.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:31:50', '2022-11-17 21:46:08'),
	(46, 'PistonAssembly	', '4D33', '', 6500.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:32:26', '2022-11-17 21:46:08'),
	(47, 'Piston Pin', '4D33', '', 375.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:32:42', '2022-11-17 21:46:08'),
	(48, 'PistonPin Bushing ', '4D33', '', 1600.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:33:02', '2022-11-17 21:46:08'),
	(49, 'PistonRing2', '4D33', '', 2900.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:33:42', '2022-11-17 21:46:08'),
	(50, 'CamshaftBushing ', '4D32', 'std', 4500.00, 'pcs', 12, '', 1, 0, '2022-10-02 23:34:44', '2022-11-17 22:15:29'),
	(51, 'Balancer Bushing', '4D32', '', 0.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:35:57', '2022-11-17 21:46:08'),
	(52, 'OilFilter ', '4D32', '', 3500.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:36:16', '2022-11-17 21:46:08'),
	(53, 'HeaterPlug', '4D33', '', 3800.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:38:41', '2022-11-17 21:46:08'),
	(54, 'FuelFilter', '4D33', '', 0.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:39:39', '2022-11-17 21:46:08'),
	(55, 'Engine Valve	', '4D33', '', 3800.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:40:08', '2022-11-17 21:46:08'),
	(56, 'Valve Guide 	', '4D33', '', 750.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:40:32', '2022-11-17 21:46:08'),
	(57, 'HeadGasket', '4D33', '', 950.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:41:16', '2022-11-17 21:46:08'),
	(58, 'ValveSeal', '4D33', '', 650.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:41:46', '2022-11-17 21:46:08'),
	(59, 'ClutchDisc', '4D33', '', 2600.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:42:07', '2022-11-17 21:46:08'),
	(60, 'Preasure Plate', '4D33', '', 0.00, 'pcs', 0, '', 1, 0, '2022-10-02 23:42:26', '2022-11-17 21:46:08');

-- Dumping structure for table hems_db.service_list
DROP TABLE IF EXISTS `service_list`;
CREATE TABLE IF NOT EXISTS `service_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `service` varchar(250) NOT NULL,
  `service_sub` varchar(250) NOT NULL,
  `cylinder` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `delete_flag` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.service_list: ~323 rows (approximately)
INSERT INTO `service_list` (`id`, `service`, `service_sub`, `cylinder`, `description`, `price`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
	(9, 'Cylinder Head', 'Valve seat ring insert', '1 Cylinder', '', 500.00, 1, 0, '2022-09-29 23:53:14', '2022-09-29 23:53:14'),
	(16, 'Engine Block', 'Rebore', '1 Cylinder', '', 1000.00, 1, 0, '2022-09-29 23:57:45', '2022-09-29 23:57:45'),
	(17, 'Cylinder Head', 'Valve Seat Ring Insert', '1 Cylinder', '', 500.00, 1, 0, '2022-09-30 21:21:39', '2022-09-30 21:21:39'),
	(18, 'Cylinder Head', 'Valve Seat Replace/ Lapping', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 21:22:08', '2022-09-30 21:22:08'),
	(19, 'Cylinder Head', 'Valve Guide Replace', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 21:22:49', '2022-09-30 21:22:49'),
	(20, 'Cylinder Head', 'Resurface', '1 Cylinder', '', 600.00, 1, 0, '2022-09-30 21:23:05', '2022-09-30 21:23:05'),
	(21, 'Cylinder Head', 'Valve Reface', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 21:23:49', '2022-09-30 21:29:49'),
	(22, 'Cylinder Head', 'Cold Welding', '1 Cylinder', '', 250.00, 1, 0, '2022-09-30 21:24:07', '2022-09-30 21:24:07'),
	(23, 'Cylinder Head', 'Hydrotest', '1 Cylinder', '', 500.00, 1, 0, '2022-09-30 21:24:26', '2022-09-30 21:24:26'),
	(24, 'Cylinder Head', 'Tappet Clearance Setting and Assembling', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 21:24:59', '2022-09-30 21:24:59'),
	(25, 'Cylinder Head', 'Line Boring of Camshaft Housing', '1 Cylinder', '', 1000.00, 1, 0, '2022-09-30 21:25:42', '2022-09-30 21:25:42'),
	(26, 'Cylinder Head', 'Valve Seat Ring Insert', '2 Cylinder', '', 800.00, 1, 0, '2022-09-30 21:26:21', '2022-09-30 21:26:21'),
	(27, 'Cylinder Head', 'Valve Seat Replace/ Lapping', '2 Cylinder', '', 400.00, 1, 0, '2022-09-30 21:27:04', '2022-09-30 21:27:04'),
	(28, 'Cylinder Head', 'Valve Guide Replace', '2 Cylinder', '', 600.00, 1, 0, '2022-09-30 21:27:30', '2022-09-30 21:27:30'),
	(29, 'Cylinder Head', 'Resurface', '2 Cylinder', '', 750.00, 1, 0, '2022-09-30 21:28:02', '2022-09-30 21:28:02'),
	(30, 'Cylinder Head', 'Valve Reface', '2 Cylinder', '', 600.00, 1, 0, '2022-09-30 21:28:34', '2022-09-30 21:28:34'),
	(31, 'Cylinder Head', 'Cold Welding', '2 Cylinder', '', 250.00, 1, 0, '2022-09-30 21:30:34', '2022-09-30 21:30:34'),
	(32, 'Cylinder Head', 'Hydrotest', '2 Cylinder', '', 750.00, 1, 0, '2022-09-30 21:31:00', '2022-09-30 21:31:00'),
	(33, 'Cylinder Head', 'Tappet Clearance Setting and Assembling', '2 Cylinder', '', 600.00, 1, 0, '2022-09-30 21:31:25', '2022-09-30 21:31:25'),
	(34, 'Cylinder Head', 'Line Boring of Camshaft Housing', '2 Cylinder', '', 1500.00, 1, 0, '2022-09-30 21:31:50', '2022-09-30 21:31:50'),
	(35, 'Cylinder Head', 'Valve Seat Ring Insert', '3 Cylinder', '', 1500.00, 1, 0, '2022-09-30 21:32:13', '2022-09-30 21:32:13'),
	(36, 'Cylinder Head', 'Valve Seat Replace/ Lapping', '3 Cylinder', '', 1200.00, 1, 0, '2022-09-30 21:32:29', '2022-11-06 16:36:49'),
	(37, 'Cylinder Head', 'Valve Guide Replace', '3 Cylinder', '', 1000.00, 1, 0, '2022-09-30 21:34:48', '2022-09-30 21:34:48'),
	(38, 'Cylinder Head', 'Resurface', '3 Cylinder', '', 1000.00, 1, 0, '2022-09-30 21:35:19', '2022-09-30 21:35:19'),
	(39, 'Cylinder Head', 'Valve Reface', '3 Cylinder', '', 900.00, 1, 0, '2022-09-30 21:35:45', '2022-09-30 21:35:45'),
	(40, 'Cylinder Head', 'Cold Welding', '3 Cylinder', '', 250.00, 1, 0, '2022-09-30 21:37:05', '2022-11-06 16:36:49'),
	(41, 'Cylinder Head', 'Hydrotest', '3 Cylinder', '', 1000.00, 1, 0, '2022-09-30 21:37:43', '2022-09-30 21:37:43'),
	(42, 'Cylinder Head', 'Tappet Clearance Setting and Assembling', '3 Cylinder', '', 900.00, 1, 0, '2022-09-30 21:38:07', '2022-09-30 21:38:07'),
	(43, 'Cylinder Head', 'Line Boring of Camshaft Housing', '3 Cylinder', '', 2000.00, 1, 0, '2022-09-30 21:38:34', '2022-09-30 21:38:34'),
	(44, 'Cylinder Head', 'Valve Seat Ring Insert', '4 Small', '', 2000.00, 1, 0, '2022-09-30 21:39:00', '2022-09-30 21:39:00'),
	(45, 'Cylinder Head', 'Valve Seat Replace/ Lapping', '4 Small', '', 800.00, 1, 0, '2022-09-30 21:39:50', '2022-09-30 21:39:50'),
	(46, 'Cylinder Head', 'Valve Guide Replace', '4 Small', '', 800.00, 1, 0, '2022-09-30 21:40:14', '2022-09-30 21:40:14'),
	(47, 'Cylinder Head', 'Resurface', '4 Small', '', 1500.00, 1, 0, '2022-09-30 21:41:05', '2022-09-30 21:41:05'),
	(48, 'Cylinder Head', 'Valve Reface', '4 Small', '', 1200.00, 1, 0, '2022-09-30 21:41:29', '2022-09-30 21:41:29'),
	(49, 'Cylinder Head', 'Cold Welding', '4 Small', '', 350.00, 1, 0, '2022-09-30 21:41:45', '2022-09-30 21:41:45'),
	(50, 'Cylinder Head', 'Hydrotest', '4 Small', '', 1200.00, 1, 0, '2022-09-30 21:42:03', '2022-09-30 21:42:03'),
	(51, 'Cylinder Head', 'Tappet Clearance Setting and Assembling', '4 Small', '', 1500.00, 1, 0, '2022-09-30 21:42:43', '2022-09-30 21:42:43'),
	(52, 'Cylinder Head', 'Line Boring of Camshaft Housing', '4 Small', '', 2500.00, 1, 0, '2022-09-30 21:42:59', '2022-09-30 21:42:59'),
	(53, 'Cylinder Head', 'Valve Seat Ring Insert', '4 Big', '', 2400.00, 1, 0, '2022-09-30 21:43:48', '2022-09-30 21:43:48'),
	(54, 'Cylinder Head', 'Valve Seat Replace/ Lapping', '4 Big', '', 800.00, 1, 0, '2022-09-30 21:44:05', '2022-09-30 21:44:05'),
	(55, 'Cylinder Head', 'Valve Guide Replace', '4 Big', '', 1200.00, 1, 0, '2022-09-30 21:44:24', '2022-09-30 21:44:24'),
	(56, 'Cylinder Head', 'Resurface', '4 Big', '', 1800.00, 1, 0, '2022-09-30 21:46:02', '2022-09-30 21:46:02'),
	(57, 'Cylinder Head', 'Valve Reface', '4 Big', '', 1500.00, 1, 0, '2022-09-30 21:46:29', '2022-09-30 21:46:29'),
	(58, 'Cylinder Head', 'Cold Welding', '4 Big', '', 350.00, 1, 0, '2022-09-30 21:46:51', '2022-09-30 21:46:51'),
	(59, 'Cylinder Head', 'Hydrotest', '4 Big', '', 1500.00, 1, 0, '2022-09-30 21:47:21', '2022-09-30 21:47:21'),
	(60, 'Cylinder Head', 'Tappet Clearance Setting and Assembling', '4 Big', '', 1500.00, 1, 0, '2022-09-30 21:47:49', '2022-09-30 21:47:49'),
	(61, 'Cylinder Head', 'Line Boring of Camshaft Housing', '4 Big', '', 3500.00, 1, 0, '2022-09-30 21:48:05', '2022-09-30 21:48:05'),
	(62, 'Cylinder Head', 'Valve Seat Ring Insert', '6 Cylinder', '', 4200.00, 1, 0, '2022-09-30 21:48:30', '2022-09-30 21:48:30'),
	(63, 'Cylinder Head', 'Valve Seat Replace/ Lapping', '6 Cylinder', '', 1800.00, 1, 0, '2022-09-30 21:48:51', '2022-09-30 21:48:51'),
	(64, 'Cylinder Head', 'Valve Guide Replace', '6 Cylinder', '', 2400.00, 1, 0, '2022-09-30 21:49:06', '2022-11-06 16:36:49'),
	(65, 'Cylinder Head', 'Resurface', '6 Cylinder', '', 2500.00, 1, 0, '2022-09-30 21:49:22', '2022-09-30 21:49:22'),
	(66, 'Cylinder Head', 'Valve Reface', '6 Cylinder', '', 1800.00, 1, 0, '2022-09-30 21:49:45', '2022-09-30 21:49:45'),
	(67, 'Cylinder Head', 'Cold Welding', '6 Cylinder', '', 450.00, 1, 0, '2022-09-30 21:50:04', '2022-09-30 21:50:04'),
	(68, 'Cylinder Head', 'Hydrotest', '6 Cylinder', '', 2500.00, 1, 0, '2022-09-30 21:50:34', '2022-09-30 21:50:34'),
	(69, 'Cylinder Head', 'Tappet Clearance Setting and Assembling', '6 Cylinder', '', 4500.00, 1, 0, '2022-09-30 21:50:53', '2022-09-30 21:50:53'),
	(70, 'Cylinder Head', 'Line Boring of Camshaft Housing', '6 Cylinder', '', 5000.00, 1, 0, '2022-09-30 21:51:14', '2022-09-30 21:51:14'),
	(71, 'Cylinder Head', 'Valve Seat Ring Insert', 'Heavy', 'Per Valve', 450.00, 1, 0, '2022-09-30 21:52:06', '2022-09-30 21:52:06'),
	(72, 'Cylinder Head', 'Valve Seat Replace/ Lapping', 'Heavy', 'Per Valve', 200.00, 1, 0, '2022-09-30 21:53:19', '2022-09-30 21:53:19'),
	(73, 'Cylinder Head', 'Valve Guide Replace', 'Heavy', 'Per Valve', 300.00, 1, 0, '2022-09-30 21:53:52', '2022-09-30 21:53:52'),
	(74, 'Cylinder Head', 'Resurface', 'Heavy', '', 3500.00, 1, 0, '2022-09-30 21:54:54', '2022-09-30 21:57:07'),
	(75, 'Cylinder Head', 'Valve Reface', 'Heavy', '', 300.00, 1, 0, '2022-09-30 21:55:16', '2022-09-30 21:58:15'),
	(76, 'Cylinder Head', 'Cold Welding', 'Heavy', '', 600.00, 1, 0, '2022-09-30 21:55:50', '2022-09-30 21:55:50'),
	(77, 'Cylinder Head', 'Hydrotest', 'Heavy', '', 2500.00, 1, 0, '2022-09-30 21:59:19', '2022-09-30 21:59:19'),
	(78, 'Cylinder Head', 'Tappet Clearance Setting and Assembling', 'Heavy', '', 6000.00, 1, 0, '2022-09-30 21:59:59', '2022-09-30 21:59:59'),
	(79, 'Cylinder Head', 'Line Boring of Camshaft Housing', 'Heavy', '', 6500.00, 1, 0, '2022-09-30 22:00:19', '2022-09-30 22:00:19'),
	(80, 'Engine Block', 'Rebore', '1 Cylinder', '', 1000.00, 1, 0, '2022-09-30 22:00:56', '2022-09-30 22:00:56'),
	(81, 'Engine Block', 'Sleeve Rebore', '1 Cylinder', '', 1500.00, 1, 0, '2022-09-30 22:01:23', '2022-09-30 22:01:23'),
	(82, 'Engine Block', 'Counterbore', '1 Cylinder', '', 850.00, 1, 0, '2022-09-30 22:02:01', '2022-09-30 22:02:01'),
	(83, 'Engine Block', 'Liner Replace', '1 Cylinder', '', 600.00, 1, 0, '2022-09-30 22:02:27', '2022-09-30 22:02:27'),
	(84, 'Engine Block', 'Block Reface', '1 Cylinder', '', 6000.00, 1, 0, '2022-09-30 22:05:03', '2022-09-30 22:05:03'),
	(85, 'Engine Block', 'Camshaft Bushing Replace', '1 Cylinder', '', 500.00, 1, 0, '2022-09-30 22:07:50', '2022-09-30 22:07:50'),
	(86, 'Engine Block', 'Line Boring of Main Housing', '1 Cylinder', '', 2500.00, 1, 0, '2022-09-30 22:08:17', '2022-09-30 22:08:17'),
	(87, 'Engine Block', 'Build up of Main Saddle', '1 Cylinder', '', 1000.00, 1, 0, '2022-09-30 22:08:45', '2022-09-30 22:08:45'),
	(88, 'Engine Block', 'Build of Trust Side', '1 Cylinder', '', 500.00, 1, 0, '2022-09-30 22:09:15', '2022-09-30 22:09:15'),
	(89, 'Engine Block', 'Washing', '1 Cylinder', '', 250.00, 1, 0, '2022-09-30 22:09:36', '2022-09-30 22:09:36'),
	(90, 'Engine Block', 'Rebore', '2 Cylinder', '', 2000.00, 1, 0, '2022-09-30 22:10:18', '2022-09-30 22:10:18'),
	(91, 'Engine Block', 'Sleeve Rebore', '2 Cylinder', '', 2500.00, 1, 0, '2022-09-30 22:10:43', '2022-09-30 22:10:43'),
	(92, 'Engine Block', 'Counterbore', '2 Cylinder', '', 850.00, 1, 0, '2022-09-30 22:11:29', '2022-09-30 22:11:29'),
	(93, 'Engine Block', 'Liner Replace', '2 Cylinder', '', 900.00, 1, 0, '2022-09-30 22:12:24', '2022-09-30 22:23:07'),
	(94, 'Engine Block', 'Block Reface', '2 Cylinder', '', 1500.00, 1, 0, '2022-09-30 22:13:01', '2022-09-30 22:13:01'),
	(95, 'Engine Block', 'Camshaft Bushing Replace', '2 Cylinder', '', 650.00, 1, 0, '2022-09-30 22:13:59', '2022-09-30 22:13:59'),
	(96, 'Engine Block', 'Line Boring of Main Housing', '2 Cylinder', '', 3500.00, 1, 0, '2022-09-30 22:14:37', '2022-09-30 22:14:37'),
	(97, 'Engine Block', 'Build up of Main Saddle', '2 Cylinder', '', 3500.00, 1, 0, '2022-09-30 22:15:35', '2022-09-30 22:23:24'),
	(98, 'Engine Block', 'Build of Trust Side', '2 Cylinder', '', 1500.00, 1, 0, '2022-09-30 22:16:01', '2022-09-30 22:16:01'),
	(99, 'Engine Block', 'Washing', '2 Cylinder', '', 250.00, 1, 0, '2022-09-30 22:16:37', '2022-09-30 22:16:37'),
	(100, 'Engine Block', 'Rebore', '3 Cylinder', '', 3500.00, 1, 0, '2022-09-30 22:18:44', '2022-09-30 22:18:44'),
	(101, 'Engine Block', 'Sleeve Rebore', '3 Cylinder', '', 3500.00, 1, 0, '2022-09-30 22:19:08', '2022-09-30 22:19:08'),
	(102, 'Engine Block', 'Counterbore', '3 Cylinder', '', 1000.00, 1, 0, '2022-09-30 22:19:28', '2022-09-30 22:19:28'),
	(103, 'Engine Block', 'Liner Replace', '3 Cylinder', '', 1200.00, 1, 0, '2022-09-30 22:19:50', '2022-09-30 22:19:50'),
	(104, 'Engine Block', 'Block Reface', '3 Cylinder', '', 2000.00, 1, 0, '2022-09-30 22:20:40', '2022-09-30 22:20:40'),
	(105, 'Engine Block', 'Camshaft Bushing Replace', '3 Cylinder', '', 800.00, 1, 0, '2022-09-30 22:21:02', '2022-09-30 22:21:02'),
	(106, 'Engine Block', 'Build up of Main Saddle', '3 Cylinder', '', 1500.00, 1, 0, '2022-09-30 22:24:02', '2022-09-30 22:24:02'),
	(107, 'Engine Block', 'Build of Trust Side', '3 Cylinder', '', 650.00, 1, 0, '2022-09-30 22:24:29', '2022-09-30 22:24:29'),
	(108, 'Engine Block', 'Washing', '3 Cylinder', '', 250.00, 1, 0, '2022-09-30 22:24:53', '2022-09-30 22:24:53'),
	(109, 'Engine Block', 'Rebore', '4 Small', '', 4000.00, 1, 0, '2022-09-30 22:25:24', '2022-09-30 22:25:24'),
	(110, 'Engine Block', 'Sleeve Rebore', '4 Small', '', 4500.00, 1, 0, '2022-09-30 22:25:47', '2022-09-30 22:25:47'),
	(111, 'Engine Block', 'Counterbore', '4 Small', '', 1200.00, 1, 0, '2022-09-30 22:26:05', '2022-09-30 22:29:21'),
	(112, 'Engine Block', 'Liner Replace', '4 Small', '', 1500.00, 1, 0, '2022-09-30 22:26:24', '2022-09-30 22:26:24'),
	(113, 'Engine Block', 'Block Reface', '4 Small', '', 2500.00, 1, 0, '2022-09-30 22:26:54', '2022-09-30 22:26:54'),
	(114, 'Engine Block', 'Camshaft Bushing Replace', '4 Small', '', 900.00, 1, 0, '2022-09-30 22:30:19', '2022-09-30 22:30:19'),
	(115, 'Engine Block', 'Line Boring of Main Housing', '4 Small', '', 4500.00, 1, 0, '2022-09-30 22:30:59', '2022-09-30 22:30:59'),
	(116, 'Engine Block', 'Build up of Main Saddle', '4 Small', 'Per Journal', 1500.00, 1, 0, '2022-09-30 22:31:25', '2022-09-30 22:31:25'),
	(117, 'Engine Block', 'Build of Trust Side', '4 Small', '', 650.00, 1, 0, '2022-09-30 22:31:59', '2022-09-30 22:31:59'),
	(118, 'Engine Block', 'Washing', '4 Small', '', 300.00, 1, 0, '2022-09-30 22:32:25', '2022-09-30 22:32:25'),
	(119, 'Engine Block', 'Rebore', '4 Big', '', 4500.00, 1, 0, '2022-09-30 22:34:06', '2022-09-30 22:34:06'),
	(120, 'Engine Block', 'Sleeve Rebore', '4 Big', '', 5000.00, 1, 0, '2022-09-30 22:34:25', '2022-09-30 22:34:25'),
	(121, 'Engine Block', 'Counterbore', '4 Big', '', 1500.00, 1, 0, '2022-09-30 22:34:45', '2022-09-30 22:34:45'),
	(122, 'Engine Block', 'Liner Replace', '4 Big', '', 1500.00, 1, 0, '2022-09-30 22:35:03', '2022-09-30 22:35:03'),
	(123, 'Engine Block', 'Block Reface', '4 Big', '', 2500.00, 1, 0, '2022-09-30 22:35:26', '2022-09-30 22:35:26'),
	(124, 'Engine Block', 'Camshaft Bushing Replace', '4 Big', '', 1200.00, 1, 0, '2022-09-30 22:36:11', '2022-09-30 22:36:11'),
	(125, 'Engine Block', 'Line Boring of Main Housing', '4 Big', '', 4500.00, 1, 0, '2022-09-30 22:36:50', '2022-09-30 22:36:50'),
	(126, 'Engine Block', 'Build up of Main Saddle', '4 Big', 'Per Journal', 2500.00, 1, 0, '2022-09-30 22:37:16', '2022-09-30 22:37:16'),
	(127, 'Engine Block', 'Build of Trust Side', '4 Big', '', 1200.00, 1, 0, '2022-09-30 22:37:38', '2022-09-30 22:37:38'),
	(128, 'Engine Block', 'Washing', '4 Big', '', 500.00, 1, 0, '2022-09-30 22:37:59', '2022-09-30 22:37:59'),
	(129, 'Engine Block', 'Rebore', '6 Cylinder', '', 6000.00, 1, 0, '2022-09-30 22:38:58', '2022-09-30 22:38:58'),
	(130, 'Engine Block', 'Sleeve Rebore', '6 Cylinder', '', 7000.00, 1, 0, '2022-09-30 22:39:20', '2022-09-30 22:39:20'),
	(131, 'Engine Block', 'Counterbore', '6 Cylinder', '', 2500.00, 1, 0, '2022-09-30 22:39:42', '2022-09-30 22:39:42'),
	(132, 'Engine Block', 'Liner Replace', '6 Cylinder', '', 2500.00, 1, 0, '2022-09-30 22:40:05', '2022-09-30 22:40:05'),
	(133, 'Engine Block', 'Block Reface', '6 Cylinder', '', 4500.00, 1, 0, '2022-09-30 22:40:37', '2022-09-30 22:40:37'),
	(134, 'Engine Block', 'Camshaft Bushing Replace', '6 Cylinder', '', 1800.00, 1, 0, '2022-09-30 22:41:11', '2022-09-30 22:41:11'),
	(135, 'Engine Block', 'Line Boring of Main Housing', '6 Cylinder', '', 6500.00, 1, 0, '2022-09-30 22:41:32', '2022-09-30 22:41:32'),
	(136, 'Engine Block', 'Build up of Main Saddle', '6 Cylinder', 'Per Journal', 2500.00, 1, 0, '2022-09-30 22:41:59', '2022-09-30 22:41:59'),
	(137, 'Engine Block', 'Build of Trust Side', '6 Cylinder', '', 1500.00, 1, 0, '2022-09-30 22:42:29', '2022-09-30 22:42:29'),
	(138, 'Engine Block', 'Washing', '6 Cylinder', '', 800.00, 1, 0, '2022-09-30 22:42:51', '2022-09-30 22:42:51'),
	(139, 'Engine Block', 'Rebore', 'Heavy', '', 7500.00, 1, 0, '2022-09-30 22:43:16', '2022-09-30 22:43:16'),
	(140, 'Engine Block', 'Sleeve Rebore', 'Heavy', '', 8500.00, 1, 0, '2022-09-30 22:43:35', '2022-09-30 22:43:35'),
	(141, 'Engine Block', 'Counterbore', 'Heavy', '', 4500.00, 1, 0, '2022-09-30 22:44:05', '2022-09-30 22:44:05'),
	(142, 'Engine Block', 'Liner Replace', 'Heavy', '', 4500.00, 1, 0, '2022-09-30 22:44:30', '2022-09-30 22:44:30'),
	(143, 'Engine Block', 'Block Reface', 'Heavy', '', 4500.00, 1, 0, '2022-09-30 22:44:48', '2022-09-30 22:44:48'),
	(144, 'Engine Block', 'Camshaft Bushing Replace', 'Heavy', '', 2500.00, 1, 0, '2022-09-30 22:45:05', '2022-09-30 22:45:05'),
	(145, 'Engine Block', 'Line Boring of Main Housing', 'Heavy', '', 7500.00, 1, 0, '2022-09-30 22:45:25', '2022-09-30 22:45:25'),
	(146, 'Engine Block', 'Build up of Main Saddle', 'Heavy', 'Per Journal', 3500.00, 1, 0, '2022-09-30 22:45:50', '2022-09-30 22:45:50'),
	(147, 'Engine Block', 'Build of Trust Side', 'Heavy', '', 3000.00, 1, 0, '2022-09-30 22:46:14', '2022-09-30 22:46:14'),
	(148, 'Engine Block', 'Washing', 'Heavy', '', 1000.00, 1, 0, '2022-09-30 22:46:45', '2022-09-30 22:46:45'),
	(149, 'Crankshaft', 'Polished', '1 Cylinder', '', 500.00, 1, 0, '2022-09-30 22:49:43', '2022-09-30 22:49:43'),
	(150, 'Crankshaft', 'Regrind of Main and Con journal', '1 Cylinder', '', 800.00, 1, 0, '2022-09-30 22:50:01', '2022-09-30 22:50:01'),
	(151, 'Crankshaft', 'Trust side machining', '1 Cylinder', '', 250.00, 1, 0, '2022-09-30 22:50:19', '2022-09-30 22:50:19'),
	(152, 'Crankshaft', 'Build up of Thrust side', '1 Cylinder', '', 600.00, 1, 0, '2022-09-30 22:50:40', '2022-09-30 22:50:40'),
	(153, 'Crankshaft', 'Oil Seal Build Up', '1 Cylinder', '', 500.00, 1, 0, '2022-09-30 22:50:56', '2022-09-30 22:50:56'),
	(154, 'Crankshaft', 'Fitting of Main and Con', '1 Cylinder', '', 850.00, 1, 0, '2022-09-30 22:51:13', '2022-09-30 22:51:13'),
	(155, 'Crankshaft', 'Alignment', '1 Cylinder', '', 850.00, 1, 0, '2022-09-30 22:51:28', '2022-09-30 22:51:28'),
	(156, 'Crankshaft', 'Rebabbit of Thrust Washer', '1 Cylinder', '', 850.00, 1, 0, '2022-09-30 22:51:48', '2022-09-30 22:51:48'),
	(157, 'Crankshaft', 'Balancer Bushing Replace', '1 Cylinder', '', 500.00, 1, 0, '2022-09-30 22:52:08', '2022-09-30 22:52:08'),
	(158, 'Crankshaft', 'Polished', '2 Cylinder', '', 500.00, 1, 0, '2022-09-30 22:52:35', '2022-09-30 22:52:35'),
	(159, 'Crankshaft', 'Regrind of Main and Con journal', '2 Cylinder', '', 1500.00, 1, 0, '2022-09-30 22:52:57', '2022-09-30 22:52:57'),
	(160, 'Crankshaft', 'Trust side machining', '2 Cylinder', '', 300.00, 1, 0, '2022-09-30 22:53:34', '2022-09-30 22:53:34'),
	(161, 'Crankshaft', 'Build up of Thrust side', '2 Cylinder', '', 900.00, 1, 0, '2022-09-30 22:53:55', '2022-09-30 22:53:55'),
	(162, 'Crankshaft', 'Oil Seal Build Up', '2 Cylinder', '', 600.00, 1, 0, '2022-09-30 22:54:12', '2022-09-30 22:54:12'),
	(163, 'Crankshaft', 'Fitting of Main and Con', '2 Cylinder', '', 1000.00, 1, 0, '2022-09-30 22:54:44', '2022-09-30 22:58:04'),
	(164, 'Crankshaft', 'Alignment', '2 Cylinder', '', 1000.00, 1, 0, '2022-09-30 22:56:43', '2022-09-30 22:58:25'),
	(165, 'Crankshaft', 'Rebabbit of Thrust Washer', '2 Cylinder', '', 1000.00, 1, 0, '2022-09-30 22:56:58', '2022-09-30 22:56:58'),
	(166, 'Crankshaft', 'Balancer Bushing Replace', '2 Cylinder', '', 600.00, 1, 0, '2022-09-30 22:57:20', '2022-09-30 22:58:48'),
	(167, 'Crankshaft', 'Polished', '3 Cylinder', '', 800.00, 1, 0, '2022-09-30 22:59:28', '2022-09-30 22:59:28'),
	(168, 'Crankshaft', 'Regrind of Main and Con journal', '3 Cylinder', '', 1750.00, 1, 0, '2022-09-30 22:59:46', '2022-09-30 22:59:46'),
	(169, 'Crankshaft', 'Trust side machining', '3 Cylinder', '', 450.00, 1, 0, '2022-09-30 23:00:02', '2022-09-30 23:00:02'),
	(170, 'Crankshaft', 'Build up of Thrust side', '3 Cylinder', '', 1200.00, 1, 0, '2022-09-30 23:00:23', '2022-09-30 23:00:23'),
	(171, 'Crankshaft', 'Oil Seal Build Up', '3 Cylinder', '', 600.00, 1, 0, '2022-09-30 23:00:51', '2022-09-30 23:00:51'),
	(172, 'Crankshaft', 'Fitting of Main and Con', '3 Cylinder', '', 1500.00, 1, 0, '2022-09-30 23:01:07', '2022-09-30 23:01:07'),
	(173, 'Crankshaft', 'Alignment', '3 Cylinder', '', 1200.00, 1, 0, '2022-09-30 23:01:22', '2022-09-30 23:01:22'),
	(174, 'Crankshaft', 'Rebabbit of Thrust Washer', '3 Cylinder', '', 1000.00, 1, 0, '2022-09-30 23:01:39', '2022-09-30 23:01:39'),
	(175, 'Crankshaft', '', '3 Cylinder', '', 900.00, 1, 0, '2022-09-30 23:01:53', '2022-09-30 23:01:53'),
	(176, 'Crankshaft', 'Polished', '4 Small', '', 900.00, 1, 0, '2022-09-30 23:02:18', '2022-09-30 23:02:18'),
	(177, 'Crankshaft', 'Regrind of Main and Con journal', '4 Small', '', 2250.00, 1, 0, '2022-09-30 23:02:38', '2022-09-30 23:02:38'),
	(178, 'Crankshaft', 'Trust side machining', '4 Small', '', 650.00, 1, 0, '2022-09-30 23:02:54', '2022-09-30 23:02:54'),
	(179, 'Crankshaft', 'Build up of Thrust side', '4 Small', '', 1500.00, 1, 0, '2022-09-30 23:03:16', '2022-09-30 23:03:16'),
	(180, 'Crankshaft', 'Oil Seal Build Up', '4 Small', '', 650.00, 1, 0, '2022-09-30 23:03:32', '2022-09-30 23:03:32'),
	(181, 'Crankshaft', 'Fitting of Main and Con', '4 Small', '', 1500.00, 1, 0, '2022-09-30 23:03:48', '2022-09-30 23:03:48'),
	(182, 'Crankshaft', 'Alignment', '4 Small', '', 1500.00, 1, 0, '2022-09-30 23:04:04', '2022-09-30 23:04:04'),
	(183, 'Crankshaft', 'Rebabbit of Thrust Washer', '4 Small', '', 1000.00, 1, 0, '2022-09-30 23:04:20', '2022-09-30 23:04:20'),
	(184, 'Crankshaft', 'Balancer Bushing Replace', '4 Small', '', 1200.00, 1, 0, '2022-09-30 23:04:34', '2022-11-06 17:20:11'),
	(185, 'Crankshaft', 'Polished', '4 Big', '', 1200.00, 1, 0, '2022-09-30 23:04:55', '2022-09-30 23:04:55'),
	(186, 'Crankshaft', 'Regrind of Main and Con journal', '4 Big', '', 2700.00, 1, 0, '2022-09-30 23:05:10', '2022-09-30 23:05:10'),
	(187, 'Crankshaft', 'Trust side machining', '4 Big', '', 750.00, 1, 0, '2022-09-30 23:05:24', '2022-09-30 23:05:24'),
	(188, 'Crankshaft', 'Build up of Thrust side', '4 Big', '', 1500.00, 1, 0, '2022-09-30 23:05:39', '2022-09-30 23:05:39'),
	(189, 'Crankshaft', 'Oil Seal Build Up', '4 Big', '', 1200.00, 1, 0, '2022-09-30 23:05:55', '2022-09-30 23:05:55'),
	(190, 'Crankshaft', 'Fitting of Main and Con', '4 Big', '', 1800.00, 1, 0, '2022-09-30 23:06:12', '2022-09-30 23:06:12'),
	(191, 'Crankshaft', 'Alignment', '4 Big', '', 2500.00, 1, 0, '2022-09-30 23:06:29', '2022-09-30 23:06:29'),
	(192, 'Crankshaft', 'Rebabbit of Thrust Washer', '4 Big', '', 1500.00, 1, 0, '2022-09-30 23:06:45', '2022-09-30 23:06:45'),
	(193, 'Crankshaft', 'Balancer Bushing Replace', '4 Big', '', 1200.00, 1, 0, '2022-09-30 23:07:00', '2022-09-30 23:07:00'),
	(194, 'Crankshaft', 'Polished', '6 Cylinder', '', 1600.00, 1, 0, '2022-09-30 23:07:23', '2022-09-30 23:07:23'),
	(195, 'Crankshaft', 'Regrind of Main and Con journal', '6 Cylinder', '', 4550.00, 1, 0, '2022-09-30 23:07:40', '2022-09-30 23:07:40'),
	(196, 'Crankshaft', 'Trust side machining', '6 Cylinder', '', 1200.00, 1, 0, '2022-09-30 23:08:03', '2022-09-30 23:08:03'),
	(197, 'Crankshaft', 'Build up of Thrust side', '6 Cylinder', '', 1800.00, 1, 0, '2022-09-30 23:08:20', '2022-09-30 23:08:20'),
	(198, 'Crankshaft', 'Oil Seal Build Up', '6 Cylinder', '', 1500.00, 1, 0, '2022-09-30 23:08:38', '2022-09-30 23:08:38'),
	(199, 'Crankshaft', 'Fitting of Main and Con', '6 Cylinder', '', 2500.00, 1, 0, '2022-09-30 23:08:54', '2022-09-30 23:08:54'),
	(200, 'Crankshaft', 'Alignment', '6 Cylinder', '', 3500.00, 1, 0, '2022-09-30 23:09:10', '2022-09-30 23:09:10'),
	(201, 'Crankshaft', 'Rebabbit of Thrust Washer', '6 Cylinder', '', 1800.00, 1, 0, '2022-09-30 23:09:26', '2022-09-30 23:09:26'),
	(202, 'Crankshaft', 'Balancer Bushing Replace', '6 Cylinder', '', 1500.00, 1, 0, '2022-09-30 23:09:43', '2022-09-30 23:09:43'),
	(203, 'Crankshaft', 'Polished', 'Heavy', '', 2000.00, 1, 0, '2022-09-30 23:10:05', '2022-09-30 23:10:05'),
	(204, 'Crankshaft', 'Regrind of Main and Con journal', 'Heavy', '', 6500.00, 1, 0, '2022-09-30 23:10:22', '2022-09-30 23:10:22'),
	(205, 'Crankshaft', 'Trust side machining', 'Heavy', '', 1800.00, 1, 0, '2022-09-30 23:10:38', '2022-09-30 23:10:38'),
	(206, 'Crankshaft', 'Build up of Thrust side', 'Heavy', '', 2500.00, 1, 0, '2022-09-30 23:10:59', '2022-09-30 23:10:59'),
	(207, 'Crankshaft', 'Oil Seal Build Up', 'Heavy', '', 2500.00, 1, 0, '2022-09-30 23:11:17', '2022-09-30 23:11:17'),
	(208, 'Crankshaft', 'Fitting of Main and Con', 'Heavy', '', 4500.00, 1, 0, '2022-09-30 23:11:37', '2022-09-30 23:11:37'),
	(209, 'Crankshaft', 'Alignment', 'Heavy', '', 5000.00, 1, 0, '2022-09-30 23:11:53', '2022-09-30 23:11:53'),
	(210, 'Crankshaft', 'Rebabbit of Thrust Washer', 'Heavy', '', 2500.00, 1, 0, '2022-09-30 23:12:09', '2022-09-30 23:12:09'),
	(211, 'Crankshaft', 'Balancer Bushing Replace', 'Heavy', '', 2500.00, 1, 0, '2022-09-30 23:12:29', '2022-09-30 23:12:29'),
	(212, 'Connecting Rod', 'Alignmentx', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 23:15:01', '2022-09-30 23:15:01'),
	(213, 'Connecting Rod', 'Piston Pin Bushing Replace', '1 Cylinder', '', 200.00, 1, 0, '2022-09-30 23:22:53', '2022-09-30 23:22:53'),
	(214, 'Connecting Rod', 'Sleeving of Piston Pin Bushing Housing', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 23:23:18', '2022-09-30 23:23:18'),
	(215, 'Connecting Rod', 'Resizing', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 23:23:35', '2022-09-30 23:23:35'),
	(216, 'Connecting Rod', 'Build up of Bearing Housing', '1 Cylinder', '', 300.00, 1, 0, '2022-09-30 23:23:53', '2022-09-30 23:23:53'),
	(217, 'Connecting Rod', 'Fitting of Piston', '1 Cylinder', '', 900.00, 1, 0, '2022-09-30 23:24:16', '2022-09-30 23:24:16'),
	(218, 'Connecting Rod', 'Conversion', '1 Cylinder', '', 1000.00, 1, 0, '2022-09-30 23:24:32', '2022-09-30 23:24:32'),
	(219, 'Connecting Rod', 'Press of Piston', '1 Cylinder', '', 650.00, 1, 0, '2022-09-30 23:24:47', '2022-09-30 23:24:47'),
	(220, 'Connecting Rod', 'Alignmentx', '2 Cylinder', '', 350.00, 1, 0, '2022-09-30 23:25:25', '2022-09-30 23:25:25'),
	(221, 'Connecting Rod', 'Piston Pin Bushing Replace', '2 Cylinder', '', 500.00, 1, 0, '2022-09-30 23:25:42', '2022-09-30 23:25:42'),
	(222, 'Connecting Rod', 'Sleeving of Piston Pin Bushing Housing', '2 Cylinder', '', 350.00, 1, 0, '2022-09-30 23:26:06', '2022-09-30 23:26:06'),
	(223, 'Connecting Rod', 'Resizing', '2 Cylinder', '', 350.00, 1, 0, '2022-09-30 23:26:21', '2022-09-30 23:26:21'),
	(224, 'Connecting Rod', 'Build up of Bearing Housing', '2 Cylinder', '', 350.00, 1, 0, '2022-09-30 23:26:37', '2022-09-30 23:26:37'),
	(225, 'Connecting Rod', 'Fitting of Piston', '2 Cylinder', '', 1200.00, 1, 0, '2022-09-30 23:26:53', '2022-09-30 23:26:53'),
	(226, 'Connecting Rod', 'Conversion', '2 Cylinder', '', 1500.00, 1, 0, '2022-09-30 23:27:15', '2022-09-30 23:27:15'),
	(227, 'Connecting Rod', 'Press of Piston', '2 Cylinder', '', 900.00, 1, 0, '2022-09-30 23:27:30', '2022-09-30 23:27:30'),
	(228, 'Connecting Rod', 'Alignmentx', '3 Cylinder', '', 500.00, 1, 0, '2022-09-30 23:27:54', '2022-09-30 23:27:54'),
	(229, 'Connecting Rod', 'Piston Pin Bushing Replace', '3 Cylinder', '', 700.00, 1, 0, '2022-09-30 23:28:10', '2022-09-30 23:28:10'),
	(230, 'Connecting Rod', 'Sleeving of Piston Pin Bushing Housing', '3 Cylinder', '', 500.00, 1, 0, '2022-09-30 23:28:27', '2022-09-30 23:28:27'),
	(231, 'Connecting Rod', 'Resizing', '3 Cylinder', '', 400.00, 1, 0, '2022-09-30 23:28:44', '2022-09-30 23:28:44'),
	(232, 'Connecting Rod', 'Build up of Bearing Housing', '3 Cylinder', '', 400.00, 1, 0, '2022-09-30 23:29:00', '2022-09-30 23:29:00'),
	(233, 'Connecting Rod', 'Fitting of Piston', '3 Cylinder', '', 1500.00, 1, 0, '2022-09-30 23:29:19', '2022-09-30 23:29:19'),
	(234, 'Connecting Rod', 'Conversion', '3 Cylinder', '', 1500.00, 1, 0, '2022-09-30 23:29:37', '2022-09-30 23:29:37'),
	(235, 'Connecting Rod', 'Press of Piston', '3 Cylinder', '', 1200.00, 1, 0, '2022-09-30 23:29:55', '2022-09-30 23:29:55'),
	(236, 'Connecting Rod', 'Alignmentx', '4 Small', '', 500.00, 1, 0, '2022-09-30 23:30:33', '2022-09-30 23:30:33'),
	(237, 'Connecting Rod', 'Piston Pin Bushing Replace', '4 Small', '', 900.00, 1, 0, '2022-09-30 23:30:55', '2022-09-30 23:30:55'),
	(238, 'Connecting Rod', 'Sleeving of Piston Pin Bushing Housing', '4 Small', '', 500.00, 1, 0, '2022-09-30 23:31:21', '2022-09-30 23:31:21'),
	(239, 'Connecting Rod', 'Resizing', '4 Small', '', 450.00, 1, 0, '2022-09-30 23:31:36', '2022-09-30 23:31:36'),
	(240, 'Connecting Rod', 'Build up of Bearing Housing', '4 Small', '', 450.00, 1, 0, '2022-09-30 23:31:50', '2022-09-30 23:31:50'),
	(241, 'Connecting Rod', 'Fitting of Piston', '4 Small', '', 2500.00, 1, 0, '2022-09-30 23:32:05', '2022-09-30 23:32:05'),
	(242, 'Connecting Rod', 'Conversion', '4 Small', '', 1500.00, 1, 0, '2022-09-30 23:32:21', '2022-09-30 23:32:21'),
	(243, 'Connecting Rod', 'Press of Piston', '4 Small', '', 1200.00, 1, 0, '2022-09-30 23:32:36', '2022-09-30 23:32:36'),
	(244, 'Connecting Rod', 'Alignmentx', '4 Big', '', 600.00, 1, 0, '2022-09-30 23:32:55', '2022-09-30 23:32:55'),
	(245, 'Connecting Rod', 'Piston Pin Bushing Replace', '4 Big', '', 1200.00, 1, 0, '2022-09-30 23:33:10', '2022-09-30 23:33:10'),
	(246, 'Connecting Rod', 'Sleeving of Piston Pin Bushing Housing', '4 Big', '', 500.00, 1, 0, '2022-09-30 23:33:30', '2022-09-30 23:33:30'),
	(247, 'Connecting Rod', 'Resizing', '4 Big', '', 600.00, 1, 0, '2022-09-30 23:33:42', '2022-09-30 23:33:42'),
	(248, 'Connecting Rod', 'Build up of Bearing Housing', '4 Big', '', 650.00, 1, 0, '2022-09-30 23:34:00', '2022-09-30 23:34:00'),
	(249, 'Connecting Rod', 'Fitting of Piston', '4 Big', '', 3500.00, 1, 0, '2022-09-30 23:34:20', '2022-09-30 23:34:20'),
	(250, 'Connecting Rod', 'Conversion', '4 Big', '', 1500.00, 1, 0, '2022-09-30 23:34:41', '2022-09-30 23:34:41'),
	(251, 'Connecting Rod', 'Press of Piston', '4 Big', '', 1500.00, 1, 0, '2022-09-30 23:35:20', '2022-09-30 23:35:20'),
	(252, 'Connecting Rod', 'Alignmentx', '6 Cylinder', '', 800.00, 1, 0, '2022-09-30 23:35:42', '2022-09-30 23:35:42'),
	(253, 'Connecting Rod', 'Piston Pin Bushing Replace', '6 Cylinder', '', 1600.00, 1, 0, '2022-09-30 23:36:01', '2022-09-30 23:36:01'),
	(254, 'Connecting Rod', 'Sleeving of Piston Pin Bushing Housing', '6 Cylinder', '', 800.00, 1, 0, '2022-09-30 23:36:19', '2022-09-30 23:36:19'),
	(255, 'Connecting Rod', 'Resizing', '6 Cylinder', '', 900.00, 1, 0, '2022-09-30 23:36:35', '2022-09-30 23:36:35'),
	(256, 'Connecting Rod', 'Build up of Bearing Housing', '6 Cylinder', '', 900.00, 1, 0, '2022-09-30 23:36:51', '2022-09-30 23:36:51'),
	(257, 'Connecting Rod', 'Fitting of Piston', '6 Cylinder', '', 4500.00, 1, 0, '2022-09-30 23:37:09', '2022-09-30 23:37:09'),
	(258, 'Connecting Rod', 'Conversion', '6 Cylinder', '', 2500.00, 1, 0, '2022-09-30 23:37:23', '2022-09-30 23:37:23'),
	(259, 'Connecting Rod', 'Press of Piston', '6 Cylinder', '', 2500.00, 1, 0, '2022-09-30 23:37:41', '2022-09-30 23:37:41'),
	(260, 'Connecting Rod', 'Alignmentx', 'Heavy', '', 1200.00, 1, 0, '2022-09-30 23:38:01', '2022-09-30 23:38:01'),
	(261, 'Connecting Rod', 'Piston Pin Bushing Replace', 'Heavy', '', 2500.00, 1, 0, '2022-09-30 23:38:19', '2022-09-30 23:38:19'),
	(262, 'Connecting Rod', 'Sleeving of Piston Pin Bushing Housing', 'Heavy', '', 1000.00, 1, 0, '2022-09-30 23:38:35', '2022-09-30 23:38:35'),
	(263, 'Connecting Rod', 'Resizing', 'Heavy', '', 1500.00, 1, 0, '2022-09-30 23:38:51', '2022-09-30 23:38:51'),
	(264, 'Connecting Rod', 'Build up of Bearing Housing', 'Heavy', '', 1500.00, 1, 0, '2022-09-30 23:39:07', '2022-09-30 23:39:07'),
	(265, 'Connecting Rod', 'Fitting of Piston', 'Heavy', '', 8500.00, 1, 0, '2022-09-30 23:39:26', '2022-09-30 23:39:26'),
	(266, 'Connecting Rod', 'Conversion', 'Heavy', '', 4500.00, 1, 0, '2022-09-30 23:39:41', '2022-09-30 23:39:41'),
	(267, 'Connecting Rod', 'Press of Piston', 'Heavy', '', 4000.00, 1, 0, '2022-09-30 23:39:58', '2022-09-30 23:39:58'),
	(268, 'Connecting Rod', 'Sample', '1 Cylinder', 'Sample', 180.00, 1, 1, '2022-10-09 15:42:54', '2022-10-09 15:43:05');

-- Dumping structure for table hems_db.system_info
DROP TABLE IF EXISTS `system_info`;
CREATE TABLE IF NOT EXISTS `system_info` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.system_info: ~5 rows (approximately)
INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
	(1, 'name', 'HEMS'),
	(6, 'short_name', 'HEMS Management System'),
	(11, 'logo', 'uploads/logo.png?v=1663865016'),
	(13, 'user_avatar', 'uploads/user_avatar.jpg'),
	(14, 'cover', 'uploads/cover.png?v=1651626884');

-- Dumping structure for table hems_db.transaction_list
DROP TABLE IF EXISTS `transaction_list`;
CREATE TABLE IF NOT EXISTS `transaction_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `user_id` int(30) NOT NULL,
  `mechanic_id` int(30) DEFAULT NULL,
  `client_id` int(30) DEFAULT NULL,
  `code` varchar(10) NOT NULL,
  `client_name` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `engine_model` varchar(250) NOT NULL,
  `vehicle_type` varchar(250) NOT NULL,
  `job_order` varchar(20) NOT NULL DEFAULT '',
  `amount` float(15,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '\r\n0=Pending,\r\n1=On-Progress,\r\n2=Done,\r\n3=Paid,\r\n4=Cancelled',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `mechanic_id` (`mechanic_id`),
  KEY `client_id_fk_tl` (`client_id`),
  CONSTRAINT `client_id_fk_tl` FOREIGN KEY (`client_id`) REFERENCES `clients_record` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `mechanic_id_fk_tl` FOREIGN KEY (`mechanic_id`) REFERENCES `mechanic_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `user_id_fk_tl` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.transaction_list: ~8 rows (approximately)
INSERT INTO `transaction_list` (`id`, `user_id`, `mechanic_id`, `client_id`, `code`, `client_name`, `contact`, `email`, `address`, `engine_model`, `vehicle_type`, `job_order`, `amount`, `status`, `date_created`, `date_updated`) VALUES
	(5, 1, 3, 2, '22110001', 'Sample Name', '0967452423426', 'sampleemail@gmail.com', 'Calapan City', '4D6', 'sedan', '0', 33650.00, 1, '2022-11-06 21:42:32', '2022-11-16 15:14:44'),
	(12, 1, 17, 4, '22110002', 'Someone', '09123456789', 'someone@gmail.com', 'address', '4D33', 'sedan', '', 14000.00, 0, '2022-11-06 23:38:57', '2022-11-16 15:14:49'),
	(13, 1, 13, 5, '22110003', 'John Doe', '09837635267', 'john@gmail.com', 'Calapan City, Ibaba', '4D33', 'SUV', '', 2500.00, 0, '2022-11-07 11:31:54', '2022-11-16 15:14:57'),
	(14, 1, 19, 5, '22110004', 'John Doe', '09837635267', 'rylesc@outlook.sbs', 'Calapan City, Ibaba', '4D33', 'SUV', '', 1800.00, 0, '2022-11-07 11:47:57', '2022-11-16 15:15:00'),
	(15, 1, 20, 6, '22110005', 'Bob Ross', '09837635267', 'ryles@outlook.sbs', 'Calapan City, Ibaba', '4D33', 'Sedan', '', 7400.00, 0, '2022-11-07 20:11:35', '2022-11-16 15:15:04'),
	(19, 1, 9, 7, '22110006', 'Somepip', '091234', 'email@gmail.com', 'somewhere pips', '4d322', 'sedan', '', 600.00, 0, '2022-11-17 00:46:40', '2022-11-16 16:48:56'),
	(20, 1, 9, 7, '22110007', 'Somepip', '091234', 'email@gmail.com', 'somewhere pips', '4d322', 'sedan', '', 300.00, 0, '2022-11-17 00:48:42', '2022-11-17 00:48:42'),
	(21, 1, 17, 8, '22110008', 'Somebimby', '091234', 'email@gmail.com', 'somewhere pips', '4d322', 'sedan', '', 1200.00, 0, '2022-11-17 00:49:21', '2022-11-17 00:49:21');

-- Dumping structure for table hems_db.transaction_products
DROP TABLE IF EXISTS `transaction_products`;
CREATE TABLE IF NOT EXISTS `transaction_products` (
  `transaction_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `price` float(15,2) NOT NULL DEFAULT '0.00',
  KEY `transaction_id` (`transaction_id`),
  KEY `service_id` (`product_id`),
  CONSTRAINT `product_id_fk_tp` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `transaction_id_fk_tp` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.transaction_products: ~7 rows (approximately)
INSERT INTO `transaction_products` (`transaction_id`, `product_id`, `qty`, `price`) VALUES
	(5, 50, 7, 4500.00),
	(5, 32, 3, 450.00),
	(12, 50, 3, 4500.00),
	(13, 33, 5, 300.00),
	(14, 33, 1, 300.00),
	(15, 32, 9, 450.00),
	(20, 33, 1, 300.00);

-- Dumping structure for table hems_db.transaction_services
DROP TABLE IF EXISTS `transaction_services`;
CREATE TABLE IF NOT EXISTS `transaction_services` (
  `transaction_id` int(30) NOT NULL,
  `service_id` int(30) NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT '0.00',
  KEY `transaction_id` (`transaction_id`),
  KEY `service_id` (`service_id`),
  CONSTRAINT `service_id_fk_ts` FOREIGN KEY (`service_id`) REFERENCES `service_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `transaction_id_fk_ts` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.transaction_services: ~10 rows (approximately)
INSERT INTO `transaction_services` (`transaction_id`, `service_id`, `price`) VALUES
	(5, 216, 300.00),
	(5, 157, 500.00),
	(12, 157, 500.00),
	(13, 174, 1000.00),
	(14, 226, 1500.00),
	(15, 107, 650.00),
	(15, 170, 1200.00),
	(15, 47, 1500.00),
	(19, 166, 600.00),
	(21, 184, 1200.00);

-- Dumping structure for table hems_db.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- Dumping data for table hems_db.users: ~2 rows (approximately)
INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
	(1, 'Gabriel', 'Andrei', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatars/1.png?v=1663858090', NULL, 1, '2021-01-20 14:02:37', '2022-09-22 22:48:27'),
	(3, 'Bob', 'Ross', 'bobross', '3501b641108f9f32d9b10d340935ee07', 'uploads/avatars/3.png?v=1663862108', NULL, 2, '2022-04-21 15:45:49', '2022-09-22 23:55:08');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
