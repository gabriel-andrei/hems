-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2022 at 03:53 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hems_db`
--
CREATE DATABASE IF NOT EXISTS `hems_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `hems_db`;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_list`
--

CREATE TABLE `inventory_list` (
  `id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT 0,
  `stock_date` date NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inventory_list`
--

INSERT INTO `inventory_list` (`id`, `product_id`, `quantity`, `stock_date`, `date_created`, `date_updated`) VALUES
(24, 9, 5, '2022-09-30', '2022-09-30 00:03:43', '2022-09-30 00:03:43'),
(25, 18, 3, '2022-09-30', '2022-09-30 08:39:01', '2022-09-30 08:39:01'),
(26, 17, 15, '2022-09-30', '2022-09-30 08:39:30', '2022-09-30 08:39:30');

-- --------------------------------------------------------

--
-- Table structure for table `mechanic_list`
--

CREATE TABLE `mechanic_list` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mechanic_list`
--

INSERT INTO `mechanic_list` (`id`, `firstname`, `middlename`, `lastname`, `status`, `delete_flag`, `date_added`, `date_updated`) VALUES
(1, 'Robert', '', 'Niro', 1, 0, '2022-05-04 11:01:51', '2022-09-23 01:36:48'),
(2, 'Chris', '', 'Lake', 1, 0, '2022-05-04 11:02:00', '2022-09-23 00:58:31');

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT 0.00,
  `image_path` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`id`, `name`, `description`, `price`, `image_path`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(9, 'Thrust Washer', '', 750.00, 'uploads/products/9.png?v=1664465151', 1, 0, '2022-09-29 23:25:51', '2022-09-29 23:25:51'),
(10, 'Overhauling Gasket', '', 0.00, 'uploads/products/10.png?v=1664465451', 1, 0, '2022-09-29 23:30:50', '2022-09-29 23:30:51'),
(11, 'Main BRG', '', 0.00, 'uploads/products/11.png?v=1664465507', 1, 0, '2022-09-29 23:31:47', '2022-09-29 23:31:47'),
(12, 'Conn BRG', '', 0.00, 'uploads/products/12.png?v=1664465548', 1, 0, '2022-09-29 23:32:28', '2022-09-29 23:32:28'),
(13, 'Liner', '', 0.00, 'uploads/products/13.png?v=1664465596', 1, 0, '2022-09-29 23:33:16', '2022-09-29 23:33:16'),
(14, 'Piston', '', 0.00, 'uploads/products/14.png?v=1664465663', 1, 0, '2022-09-29 23:34:22', '2022-09-29 23:34:23'),
(15, 'Piston Pin Bushing', '', 0.00, 'uploads/products/15.png?v=1664465735', 1, 0, '2022-09-29 23:35:35', '2022-09-29 23:35:35'),
(16, 'Piston Ring', '', 0.00, 'uploads/products/16.png?v=1664465787', 1, 0, '2022-09-29 23:36:27', '2022-09-29 23:36:27'),
(17, 'Camshaft Bushing', '', 0.00, 'uploads/products/17.png?v=1664465846', 1, 0, '2022-09-29 23:37:26', '2022-09-29 23:37:26'),
(18, 'Balancer Bushing', '', 0.00, 'uploads/products/18.png?v=1664465917', 1, 0, '2022-09-29 23:38:37', '2022-09-29 23:38:37'),
(19, 'Oil Filter', '', 0.00, 'uploads/products/19.png?v=1664465955', 1, 0, '2022-09-29 23:39:15', '2022-09-29 23:39:15'),
(20, 'Engine Valve', '', 0.00, 'uploads/products/20.png?v=1664465995', 1, 0, '2022-09-29 23:39:55', '2022-09-29 23:39:55'),
(21, 'Valve Guide', '', 0.00, 'uploads/products/21.png?v=1664466070', 1, 0, '2022-09-29 23:41:10', '2022-09-29 23:41:10'),
(22, 'Head Gasket', '', 0.00, 'uploads/products/22.png?v=1664466109', 1, 0, '2022-09-29 23:41:49', '2022-09-29 23:41:49'),
(23, 'Valve Seal', '', 0.00, 'uploads/products/23.png?v=1664466157', 1, 0, '2022-09-29 23:42:37', '2022-09-29 23:42:37'),
(24, 'Diesel Oil', '', 0.00, 'uploads/products/24.png?v=1664466211', 1, 0, '2022-09-29 23:43:31', '2022-09-29 23:43:31');

-- --------------------------------------------------------

--
-- Table structure for table `service_list`
--

CREATE TABLE `service_list` (
  `id` int(30) NOT NULL,
  `service` varchar(250) NOT NULL,
  `service_sub` varchar(250) NOT NULL,
  `cylinder` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_list`
--

INSERT INTO `service_list` (`id`, `service`, `service_sub`, `cylinder`, `description`, `price`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(9, 'Cylinder Head', 'Valve seat ring insert', '1 Cylinder', '', 500.00, 1, 0, '2022-09-29 23:53:14', '2022-09-29 23:53:14'),
(16, 'Engine Block', 'Rebore', '1 Cylinder', '', 1000.00, 1, 0, '2022-09-29 23:57:45', '2022-09-29 23:57:45');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'HEMS'),
(6, 'short_name', 'HEMS Management System'),
(11, 'logo', 'uploads/logo.png?v=1663865016'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover.png?v=1651626884');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_list`
--

CREATE TABLE `transaction_list` (
  `id` int(30) NOT NULL,
  `user_id` int(30) NOT NULL,
  `mechanic_id` int(30) DEFAULT NULL,
  `code` varchar(100) NOT NULL,
  `client_name` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `address` text NOT NULL,
  `engine_model` varchar(250) NOT NULL,
  `job_order` int(30) NOT NULL,
  `amount` float(15,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(2) NOT NULL DEFAULT 0 COMMENT '\r\n0=Pending,\r\n1=On-Progress,\r\n2=Done,\r\n3=Paid,\r\n4=Cancelled',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction_list`
--

INSERT INTO `transaction_list` (`id`, `user_id`, `mechanic_id`, `code`, `client_name`, `contact`, `email`, `address`, `engine_model`, `job_order`, `amount`, `status`, `date_created`, `date_updated`) VALUES
(1, 1, 1, '202205040001', 'John D Smith', '09123654789', 'jsmith@sample.com', 'Sample Address Only', '', 0, 2250.00, 3, '2022-05-04 11:07:11', '2022-05-04 13:12:23'),
(2, 1, 2, '202209210001', 'Gabriel Abarintos', '09732677312', 'gabriel@gmail.com', 'Calapan City, Oriental Mindoro', '', 0, 9600.00, 2, '2022-09-21 21:29:51', '2022-09-21 21:31:49');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_products`
--

CREATE TABLE `transaction_products` (
  `transaction_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT 0,
  `price` float(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_services`
--

CREATE TABLE `transaction_services` (
  `transaction_id` int(30) NOT NULL,
  `service_id` int(30) NOT NULL,
  `price` float(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Gabriel', 'Andrei', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatars/1.png?v=1663858090', NULL, 1, '2021-01-20 14:02:37', '2022-09-22 22:48:27'),
(3, 'Bob', 'Ross', 'bobross', '3501b641108f9f32d9b10d340935ee07', 'uploads/avatars/3.png?v=1663862108', NULL, 2, '2022-04-21 15:45:49', '2022-09-22 23:55:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory_list`
--
ALTER TABLE `inventory_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `mechanic_list`
--
ALTER TABLE `mechanic_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_list`
--
ALTER TABLE `service_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_list`
--
ALTER TABLE `transaction_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `mechanic_id` (`mechanic_id`);

--
-- Indexes for table `transaction_products`
--
ALTER TABLE `transaction_products`
  ADD KEY `transaction_id` (`transaction_id`),
  ADD KEY `service_id` (`product_id`);

--
-- Indexes for table `transaction_services`
--
ALTER TABLE `transaction_services`
  ADD KEY `transaction_id` (`transaction_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory_list`
--
ALTER TABLE `inventory_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `mechanic_list`
--
ALTER TABLE `mechanic_list`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `service_list`
--
ALTER TABLE `service_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `transaction_list`
--
ALTER TABLE `transaction_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory_list`
--
ALTER TABLE `inventory_list`
  ADD CONSTRAINT `product_id_fk_il` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `transaction_list`
--
ALTER TABLE `transaction_list`
  ADD CONSTRAINT `mechanic_id_fk_tl` FOREIGN KEY (`mechanic_id`) REFERENCES `mechanic_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `user_id_fk_tl` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `transaction_products`
--
ALTER TABLE `transaction_products`
  ADD CONSTRAINT `product_id_fk_tp` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `transaction_id_fk_tp` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `transaction_services`
--
ALTER TABLE `transaction_services`
  ADD CONSTRAINT `service_id_fk_ts` FOREIGN KEY (`service_id`) REFERENCES `service_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `transaction_id_fk_ts` FOREIGN KEY (`transaction_id`) REFERENCES `transaction_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
